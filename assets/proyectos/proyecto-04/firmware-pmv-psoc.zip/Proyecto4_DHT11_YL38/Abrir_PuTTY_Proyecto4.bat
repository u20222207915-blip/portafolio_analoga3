@echo off
REM ==========================================================================
REM  Proyecto 4 - Abre PuTTY en el puerto USB-UART del KitProg (PSoC 5LP)
REM  Configuracion igual al Proyecto 1: 57600 baud, 8 datos, sin paridad,
REM  1 stop, sin control de flujo. Guarda la sesion "Proyecto4_PSoC".
REM ==========================================================================
setlocal
set "BAUD=57600"
set "SESION=Proyecto4_PSoC"
set "PUTTY=C:\Program Files\PuTTY\putty.exe"
set "COMPORT="

echo Buscando el puerto COM del KitProg...
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "$p = Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '(KitProg|USBUART|USB-UART).*\(COM\d+\)' } | Select-Object -First 1; if ($p) { [regex]::Match($p.Name,'COM\d+').Value }"`) do set "COMPORT=%%P"

if "%COMPORT%"=="" (
    echo.
    echo No se encontro el KitProg. Puertos COM disponibles:
    powershell -NoProfile -Command "Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '\(COM\d+\)' } | ForEach-Object { '  ' + $_.Name }"
    echo.
    set /p "COMPORT=Escriba el puerto (ej. COM5) y Enter: "
)

echo Puerto: %COMPORT%  ^|  %BAUD% 8N1
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v Protocol           /t REG_SZ    /d serial              /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialLine         /t REG_SZ    /d %COMPORT%           /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialSpeed        /t REG_DWORD /d %BAUD%              /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialDataBits     /t REG_DWORD /d 8                   /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialStopHalfbits /t REG_DWORD /d 2                   /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialParity       /t REG_DWORD /d 0                   /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v SerialFlowControl  /t REG_DWORD /d 0                   /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v WinTitle           /t REG_SZ    /d "Proyecto 4 - DHT11 + YL-38 (%COMPORT%)" /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v NoRemoteWinTitle   /t REG_DWORD /d 1                   /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v TermHeight         /t REG_DWORD /d 30                  /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v TermWidth          /t REG_DWORD /d 110                 /f >nul
reg add "HKCU\Software\SimonTatham\PuTTY\Sessions\%SESION%" /v ScrollbackLines    /t REG_DWORD /d 5000                /f >nul

start "" "%PUTTY%" -load "%SESION%"
endlocal
