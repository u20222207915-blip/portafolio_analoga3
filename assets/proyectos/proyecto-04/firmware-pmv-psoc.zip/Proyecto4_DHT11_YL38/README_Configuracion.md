# Proyecto 4 – Configuración PSoC Creator (PSoC 5LP · CY8CKIT-059)

Base reutilizada de `HolaMundo_PSoC` (Proyecto 1): `ADC_DelSig_1`, `UART_1`, `sprintf` + `UART_1_PutString`, formato `Campo: valor | Campo: valor\r\n`.

## 1. Crear el proyecto
1. Abrir `HolaMundo_PSoC.cywrk` → clic derecho en `HolaMundo` → **Copy / Paste** (o *File → Save Project As*) → guardar como `Proyecto_4.cydsn` dentro de esta carpeta.
2. Reemplazar `main.c` y agregar (**Add → Existing Item**) `dht11.c`, `dht11.h`, `yl38.c`, `yl38.h`.
3. Editar TopDesign y pines (secciones 2 y 3) → **Build** → **Program**.

## 2. Bloques de TopDesign.cysch

| Componente | Nombre | Configuración |
|---|---|---|
| Delta Sigma ADC | `ADC_DelSig_1` | Sin cambios respecto al P1: 16 bits, *Continuous*, 10 000 SPS, *Single ended*, rango Vssa–Vdda |
| UART (v2.50) | `UART_1` | Sin cambios: *Full UART*, 57 600 baud, 8N1 |
| Analog Pin | `YL38_AO` | Renombrar `Pin_1` del P1; cable a la entrada + del ADC |
| Digital Output Pin | `LED_Interno` | Renombrar `LED`; *Strong drive*, sin *HW connection*, inicial 0 |
| Digital Input Pin | `SW_Interno` | *Resistive pull up*, sin *HW connection*, inicial 1 |
| Digital Bidirectional Pin | `DHT11_Data` | Input + Output marcados, **Open Drain, Drives Low**, inicial 1, sin *HW connection* |
| Digital I/O Pins | `Rx_1`, `Tx_1` | Sin cambios |

No se agrega Timer ni ISR en el esquemático: la base de 1 ms es el **SysTick** (`CySysTickStart()` + callback con antirrebote de 20 ms).

**System (.cydwr → System):** VDDA = VDDD = 5.0 V (alimentación USB del kit). Heap ≥ 0x200 para `sprintf`.

## 3. Mapeo de pines (.cydwr → Pins)

| Señal | Pin | Conexión |
|---|---|---|
| `LED_Interno` | P2[1] | LED del kit (activo en alto) |
| `SW_Interno` | P2[2] | Pulsador SW1 del kit (a GND) |
| `Rx_1` | P12[6] | Puente USB-UART del KitProg |
| `Tx_1` | P12[7] | Puente USB-UART del KitProg |
| `YL38_AO` | P0[0] | AO del YL-38 (mismo pin del LDR en P1) |
| `DHT11_Data` | P3[0] | DATA del DHT11 + pull-up 10 kΩ a VDD (si el módulo no la trae) |

Sensores: VCC → VDD 5 V, GND → GND. El pin DO del YL-38 no se usa.

## 4. Funcionamiento

| Pulso | Estado | Sensores / UART | LED |
|---|---|---|---|
| Arranque | Boot → 0 | — | Fijo 3 s y se apaga |
| 1 | 1 | DHT11 cada 2 s | Fijo |
| 2 | 2 | YL-38 cada 1 s (promedio 8 muestras) | Conmuta cada 4 s |
| 3 | 3 | DHT11 + YL-38 cada 2 s | Estroboscópico 12.5 Hz |
| 4 | 0 | Ninguno (ADC detenido) | Apagado |

PuTTY: *Serial*, puerto COM del KitProg, **57600**, 8N1. Ejemplo estado 3:
`Temperatura: 26.0 C | Humedad relativa: 58% | Voltaje: 3.215 V | Humedad YL-38: 42%`

## 5. Ajustes
- Calibración YL-38 (`yl38.h`): `YL38_MV_SECO` y `YL38_MV_MOJADO` con el voltaje medido en seco y en agua.
- Tiempos (`main.c`): `T_DEBOUNCE_MS`, `T_LED_LENTO_MS`, `T_LED_ESTROBO_MS`, `T_TX_DHT_MS`, `T_TX_YL_MS`.
- El pulso de inicio del DHT11 (20 ms) es no bloqueante; solo la captura de los 40 bits (~4 ms) es síncrona y el pulsador sigue atendido por la ISR.
