/* ============================================================================
 * yl38.h - Lectura analogica del modulo YL-38 (+ sonda YL-69 / FC-37)
 * Usa ADC_DelSig_1 del Proyecto 1 (16 bits, continuo, Vssa-Vdda).
 * ==========================================================================*/
#ifndef YL38_H
#define YL38_H

#include <project.h>

/* Calibracion: medir AO (mV) con la sonda seca y con la sonda mojada */
#define YL38_MV_SECO        4700    /* AO alto  -> sonda seca   (0 %)   */
#define YL38_MV_MOJADO      1200    /* AO bajo  -> sonda mojada (100 %) */
#define YL38_N_PROMEDIO     8u      /* Muestras promediadas por lectura */

typedef struct
{
    int32 mvolts;       /* Voltaje AO en mV                     */
    int32 v_int;        /* Parte entera (V)  para imprimir      */
    int32 v_frac;       /* Milivoltios       para imprimir      */
    int32 humedad_pct;  /* 0 % seco ... 100 % mojado            */
} yl38_dato_t;

void  YL38_Iniciar(void);
void  YL38_Detener(void);
uint8 YL38_Leer(yl38_dato_t *dato);

#endif /* YL38_H */
