/* ============================================================================
 * Proyecto 4 - Placa expansora DHT11 + YL-38 (PSoC 5LP / CY8CKIT-059)
 * Base: Proyecto 1 (HolaMundo_PSoC) -> ADC_DelSig_1 + UART_1 + sprintf.
 *
 * FSM con SW_Interno:  Boot(3 s LED fijo) -> E0 -> E1 -> E2 -> E3 -> E0 ...
 *   E0 Reposo : sensores OFF          | LED OFF
 *   E1 DHT11  : DHT11 ON, YL-38 OFF   | LED fijo
 *   E2 YL-38  : DHT11 OFF, YL-38 ON   | LED conmuta cada 4 s
 *   E3 Dual   : DHT11 + YL-38         | LED estroboscopico (12.5 Hz)
 *
 * Base de tiempo: SysTick 1 ms (ISR) -> tick_ms + antirrebote del pulsador.
 * Bucle principal sin CyDelay(): todo se programa por diferencia de ticks.
 * ==========================================================================*/
#include <project.h>
#include <stdio.h>
#include "dht11.h"
#include "yl38.h"

#define TRANSMIT_BUFFER_SIZE    160     /* La trama dual ocupa ~95 caracteres */

/* ---- Niveles del hardware (CY8CKIT-059) ---- */
#define LED_ON                  1u
#define LED_OFF                 0u
#define SW_PRESIONADO           0u      /* Pulsador a GND con pull-up */
#define SW_SUELTO               1u

/* ---- Tiempos en ms ---- */
#define T_BOOT_MS               3000u
#define T_DEBOUNCE_MS           20u
#define T_LED_LENTO_MS          4000u
#define T_LED_ESTROBO_MS        40u     /* Conmuta cada 40 ms -> 12.5 Hz */
#define T_TX_DHT_MS             2000u   /* >= DHT11_PERIODO_MIN_MS        */
#define T_TX_YL_MS              1000u

typedef enum
{
    EST_REPOSO = 0,
    EST_DHT11  = 1,
    EST_YL38   = 2,
    EST_DUAL   = 3,
    EST_BOOT   = 4
} estado_t;

/* ---- Variables compartidas con la ISR ---- */
static volatile uint32 tick_ms   = 0u;
static volatile uint8  sw_evento = 0u;

/* ---- Estado de la aplicacion ---- */
static estado_t     estado     = EST_BOOT;
static uint8        led_nivel  = LED_OFF;
static uint32       t_led      = 0u;
static uint32       t_dht      = 0u;
static uint32       t_yl       = 0u;
static yl38_dato_t  yl         = {0, 0, 0, 0};
static uint8        yl_valido  = 0u;
static char         transmit_buffer[TRANSMIT_BUFFER_SIZE];

/* ===================== Base de tiempo + antirrebote ===================== */
static void SysTick_ISR(void)
{
    static uint8 sw_estable = SW_SUELTO;
    static uint8 cuenta     = 0u;
    uint8 lectura = SW_Interno_Read();

    tick_ms++;

    if(lectura != sw_estable)
    {
        if(++cuenta >= T_DEBOUNCE_MS)       /* 20 ms estable -> cambio valido */
        {
            sw_estable = lectura;
            cuenta     = 0u;
            if(sw_estable == SW_PRESIONADO)
            {
                sw_evento = 1u;             /* Solo flanco de bajada */
            }
        }
    }
    else
    {
        cuenta = 0u;
    }
}

static uint32 Millis(void)
{
    return tick_ms;                         /* Lectura de 32 bits atomica en CM3 */
}

static uint8 SW_Pulsado(void)
{
    uint8 irq = CyEnterCriticalSection();
    uint8 ev  = sw_evento;
    sw_evento = 0u;
    CyExitCriticalSection(irq);
    return ev;
}

/* ================================ LED ==================================== */
static void LED_Set(uint8 nivel)
{
    led_nivel = nivel;
    LED_Interno_Write(nivel);
}

static void LED_Tarea(uint32 ahora)
{
    uint32 periodo;

    if(estado == EST_YL38)
    {
        periodo = T_LED_LENTO_MS;
    }
    else if(estado == EST_DUAL)
    {
        periodo = T_LED_ESTROBO_MS;
    }
    else
    {
        return;                             /* E0/E1/Boot: nivel fijo */
    }

    if((uint32)(ahora - t_led) >= periodo)
    {
        t_led += periodo;
        LED_Set(led_nivel ? LED_OFF : LED_ON);
    }
}

/* ============================ Telemetria UART ============================ */
static void UART_Estado(const char *texto)
{
    sprintf(transmit_buffer, "\r\n>> Estado %d: %s\r\n", (int)estado, texto);
    UART_1_PutString(transmit_buffer);
}

static void UART_DHT11(const dht11_dato_t *d)
{
    sprintf(transmit_buffer,
            "Temperatura: %d.%01u C | Humedad relativa: %u.%01u%%\r\n",
            (int)d->temp_int, (unsigned)d->temp_dec,
            (unsigned)d->hum_int, (unsigned)d->hum_dec);
    UART_1_PutString(transmit_buffer);
}

static void UART_YL38(const yl38_dato_t *y)
{
    sprintf(transmit_buffer,
            "Voltaje: %ld.%03ld V | Humedad YL-38: %ld%%\r\n",
            (long)y->v_int, (long)y->v_frac, (long)y->humedad_pct);
    UART_1_PutString(transmit_buffer);
}

static void UART_Dual(const dht11_dato_t *d, const yl38_dato_t *y)
{
    sprintf(transmit_buffer,
            "Temperatura: %d.%01u C | Humedad relativa: %u%% | Voltaje: %ld.%03ld V | Humedad YL-38: %ld%%\r\n",
            (int)d->temp_int, (unsigned)d->temp_dec, (unsigned)d->hum_int,
            (long)y->v_int, (long)y->v_frac, (long)y->humedad_pct);
    UART_1_PutString(transmit_buffer);
}

static void UART_ErrorDHT(dht11_estado_t e)
{
    UART_1_PutString((e == DHT11_ERR_CHECKSUM) ? "DHT11: error de checksum\r\n"
                                               : "DHT11: sin respuesta (revisar cableado)\r\n");
}

/* ============================ Maquina de estados ========================= */
static void Entrar_Estado(estado_t nuevo, uint32 ahora)
{
    estado = nuevo;
    t_led  = ahora;
    t_dht  = ahora - T_TX_DHT_MS;           /* Primera lectura inmediata */
    t_yl   = ahora;
    yl_valido = 0u;

    DHT11_Detener();
    YL38_Detener();

    switch(estado)
    {
        case EST_DHT11:
            LED_Set(LED_ON);
            UART_Estado("Solo DHT11");
            break;

        case EST_YL38:
            YL38_Iniciar();
            LED_Set(LED_ON);
            UART_Estado("Solo YL-38");
            break;

        case EST_DUAL:
            YL38_Iniciar();
            LED_Set(LED_ON);
            UART_Estado("Modo dual DHT11 + YL-38");
            break;

        case EST_REPOSO:
        default:
            estado = EST_REPOSO;
            LED_Set(LED_OFF);
            UART_Estado("Reposo (sensores apagados)");
            break;
    }
}

static void Sensores_Tarea(uint32 ahora)
{
    dht11_dato_t   dht;
    dht11_estado_t r;
    uint8 usa_dht = (estado == EST_DHT11) || (estado == EST_DUAL);
    uint8 usa_yl  = (estado == EST_YL38)  || (estado == EST_DUAL);

    /* YL-38: refresca el promedio continuamente (no bloqueante) */
    if(usa_yl && YL38_Leer(&yl))
    {
        yl_valido = 1u;
    }

    if(estado == EST_YL38 && yl_valido && ((uint32)(ahora - t_yl) >= T_TX_YL_MS))
    {
        t_yl += T_TX_YL_MS;
        UART_YL38(&yl);
    }

    if(!usa_dht)
    {
        return;
    }

    /* DHT11: dispara cada T_TX_DHT_MS y procesa cuando venza el pulso start */
    if(!DHT11_Ocupado() && ((uint32)(ahora - t_dht) >= T_TX_DHT_MS))
    {
        t_dht = ahora;
        DHT11_Solicitar(ahora);
    }

    r = DHT11_Procesar(ahora, &dht);
    if(r == DHT11_OK)
    {
        if(estado == EST_DUAL && yl_valido)
        {
            UART_Dual(&dht, &yl);
        }
        else
        {
            UART_DHT11(&dht);
        }
    }
    else if(r != DHT11_PENDIENTE)
    {
        UART_ErrorDHT(r);
        if(estado == EST_DUAL && yl_valido)
        {
            UART_YL38(&yl);
        }
    }
}

/* ================================= main ================================== */
int main(void)
{
    uint32 ahora;
    uint32 t_boot;

    CyGlobalIntEnable;

    ADC_DelSig_1_Start();                   /* Conversion arranca solo en E2/E3 */
    UART_1_Start();
    DHT11_Init();

    CySysTickStart();                       /* 1 ms */
    CySysTickSetCallback(0u, SysTick_ISR);

    UART_1_PutString("\r\n--- Proyecto 4: Monitor DHT11 + YL-38 (PSoC 5LP) ---\r\n");
    UART_1_PutString("Pulse SW para cambiar de estado: 1=DHT11, 2=YL-38, 3=Dual, 4=Reposo\r\n");

    /* Secuencia de arranque: LED fijo 3 s (tambien da el 1 s que pide el DHT11) */
    estado = EST_BOOT;
    LED_Set(LED_ON);
    t_boot = Millis();

    for(;;)
    {
        ahora = Millis();

        if(estado == EST_BOOT)
        {
            if((uint32)(ahora - t_boot) >= T_BOOT_MS)
            {
                (void)SW_Pulsado();         /* Descarta pulsos durante el boot */
                Entrar_Estado(EST_REPOSO, ahora);
            }
            continue;
        }

        if(SW_Pulsado())
        {
            Entrar_Estado((estado_t)((estado + 1u) % 4u), ahora);
        }

        LED_Tarea(ahora);
        Sensores_Tarea(ahora);
    }
}
