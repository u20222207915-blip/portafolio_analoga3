/* ============================================================================
 * dht11.h - Driver no bloqueante del DHT11 (PSoC 5LP)
 * Proyecto 4 - Placa expansora DHT11 + YL-38
 *
 * Pin requerido en TopDesign: DHT11_Data (Digital Bidirectional,
 * Open Drain Drives Low, estado inicial 1, sin HW connection).
 * ==========================================================================*/
#ifndef DHT11_H
#define DHT11_H

#include <project.h>

/* Tiempos del protocolo (datasheet DHT11) */
#define DHT11_T_START_MS        20u     /* Pulso bajo de inicio (>= 18 ms)        */
#define DHT11_T_MUESTREO_US     35u     /* Muestreo del bit tras flanco de subida */
#define DHT11_TIMEOUT_US        120u    /* Timeout de cada espera de flanco       */
#define DHT11_PERIODO_MIN_MS    1000u   /* Minimo entre lecturas                  */

/* Resultado de DHT11_Procesar() */
typedef enum
{
    DHT11_PENDIENTE = 0,    /* Sin lectura en curso o esperando el pulso start */
    DHT11_OK,               /* Trama nueva valida en *dato                     */
    DHT11_ERR_TIMEOUT,      /* El sensor no respondio                          */
    DHT11_ERR_CHECKSUM      /* Trama recibida con checksum incorrecto          */
} dht11_estado_t;

typedef struct
{
    uint8 hum_int;      /* Humedad relativa, parte entera (%)  */
    uint8 hum_dec;      /* Humedad relativa, decimal           */
    int8  temp_int;     /* Temperatura, parte entera (C)       */
    uint8 temp_dec;     /* Temperatura, decimal                */
} dht11_dato_t;

void            DHT11_Init(void);
void            DHT11_Solicitar(uint32 ahora_ms);
dht11_estado_t  DHT11_Procesar(uint32 ahora_ms, dht11_dato_t *dato);
uint8           DHT11_Ocupado(void);
void            DHT11_Detener(void);

#endif /* DHT11_H */
