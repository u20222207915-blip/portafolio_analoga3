/* ============================================================================
 * yl38.c - Conversion ADC -> mV -> % de humedad del YL-38
 * Misma cadena de conversion que el Proyecto 1 (LDR): GetResult32 ->
 * CountsTo_mVolts -> separacion V / mV para sprintf.
 * ==========================================================================*/
#include "yl38.h"

static uint8 yl38_activo = 0u;
static int32 acumulado   = 0;
static uint8 n_muestras  = 0u;

void YL38_Iniciar(void)
{
    acumulado  = 0;
    n_muestras = 0u;
    ADC_DelSig_1_StartConvert();
    yl38_activo = 1u;
}

void YL38_Detener(void)
{
    ADC_DelSig_1_StopConvert();
    yl38_activo = 0u;
}

/* Devuelve 1 si hay dato nuevo en *dato. No bloquea: solo toma las
 * muestras que el ADC (modo continuo) ya tiene listas. */
uint8 YL38_Leer(yl38_dato_t *dato)
{
    int32 mv;
    int32 pct;

    if(!yl38_activo)
    {
        return 0u;
    }

    if(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_RETURN_STATUS))
    {
        mv = ADC_DelSig_1_CountsTo_mVolts(ADC_DelSig_1_GetResult32());
        if(mv < 0)
        {
            mv = 0;
        }
        acumulado += mv;
        n_muestras++;
    }

    if(n_muestras < YL38_N_PROMEDIO)
    {
        return 0u;
    }

    mv = acumulado / (int32)YL38_N_PROMEDIO;
    acumulado  = 0;
    n_muestras = 0u;

    /* AO baja cuando hay agua: relacion inversa */
    if(mv >= YL38_MV_SECO)
    {
        pct = 0;
    }
    else if(mv <= YL38_MV_MOJADO)
    {
        pct = 100;
    }
    else
    {
        pct = ((YL38_MV_SECO - mv) * 100) / (YL38_MV_SECO - YL38_MV_MOJADO);
    }

    dato->mvolts      = mv;
    dato->v_int       = mv / 1000;
    dato->v_frac      = mv % 1000;
    dato->humedad_pct = pct;
    return 1u;
}
