/* ============================================================================
 * dht11.c - Driver no bloqueante del DHT11 (protocolo 1-Wire propietario)
 *
 * Fase 1 (no bloqueante): DHT11_Solicitar() baja la linea y retorna.
 *          El main sigue atendiendo pulsador/LED mientras pasan 20 ms.
 * Fase 2 (corta, ~4-5 ms): DHT11_Procesar() suelta la linea y captura los
 *          40 bits. Las interrupciones quedan habilitadas: la ISR del
 *          SysTick dura ~1 us y el muestreo a 35 us tolera ese retardo
 *          (bit 0 = 26-28 us en alto, bit 1 = 70 us en alto).
 * ==========================================================================*/
#include "dht11.h"

#define LINEA_BAJA      0u
#define LINEA_LIBRE     1u      /* Open drain: 1 = suelta, la sube el pull-up */

static uint8  dht_activo  = 0u; /* 1 = pulso start en curso */
static uint32 t_inicio_ms = 0u;

/* Espera a que la linea llegue a 'nivel'. Devuelve 0 si vence el timeout. */
static uint8 Esperar_Nivel(uint8 nivel, uint16 timeout_us)
{
    while(DHT11_Data_Read() != nivel)
    {
        if(timeout_us == 0u)
        {
            return 0u;
        }
        timeout_us--;
        CyDelayUs(1u);
    }
    return 1u;
}

/* Captura respuesta + 40 bits. Devuelve 0 si hubo timeout. */
static uint8 Capturar_Trama(uint8 *b)
{
    uint8 i;

    DHT11_Data_Write(LINEA_LIBRE);
    CyDelayUs(30u);

    /* Respuesta del sensor: ~80 us bajo + ~80 us alto */
    if(!Esperar_Nivel(LINEA_BAJA,  DHT11_TIMEOUT_US)) return 0u;
    if(!Esperar_Nivel(LINEA_LIBRE, DHT11_TIMEOUT_US)) return 0u;
    if(!Esperar_Nivel(LINEA_BAJA,  DHT11_TIMEOUT_US)) return 0u;

    for(i = 0u; i < 40u; i++)
    {
        if(!Esperar_Nivel(LINEA_LIBRE, DHT11_TIMEOUT_US)) return 0u; /* fin de los 50 us bajos */
        CyDelayUs(DHT11_T_MUESTREO_US);
        b[i >> 3] <<= 1;
        if(DHT11_Data_Read() == LINEA_LIBRE)
        {
            b[i >> 3] |= 1u;                                         /* bit = 1 (70 us alto) */
            if(!Esperar_Nivel(LINEA_BAJA, DHT11_TIMEOUT_US)) return 0u;
        }
    }
    return 1u;
}

void DHT11_Init(void)
{
    DHT11_Data_Write(LINEA_LIBRE);
    dht_activo = 0u;
}

void DHT11_Solicitar(uint32 ahora_ms)
{
    if(!dht_activo)
    {
        DHT11_Data_Write(LINEA_BAJA);   /* Inicio de la trama */
        t_inicio_ms = ahora_ms;
        dht_activo  = 1u;
    }
}

dht11_estado_t DHT11_Procesar(uint32 ahora_ms, dht11_dato_t *dato)
{
    uint8 b[5] = {0u, 0u, 0u, 0u, 0u};

    if(!dht_activo || ((uint32)(ahora_ms - t_inicio_ms) < DHT11_T_START_MS))
    {
        return DHT11_PENDIENTE;
    }

    dht_activo = 0u;

    if(!Capturar_Trama(b))
    {
        DHT11_Data_Write(LINEA_LIBRE);
        return DHT11_ERR_TIMEOUT;
    }

    if((uint8)(b[0] + b[1] + b[2] + b[3]) != b[4])
    {
        return DHT11_ERR_CHECKSUM;
    }

    dato->hum_int  = b[0];
    dato->hum_dec  = b[1];
    dato->temp_int = (int8)b[2];
    dato->temp_dec = b[3] & 0x7Fu;
    if(b[3] & 0x80u)                    /* Bit de signo (versiones nuevas) */
    {
        dato->temp_int = -dato->temp_int;
    }
    return DHT11_OK;
}

uint8 DHT11_Ocupado(void)
{
    return dht_activo;
}

void DHT11_Detener(void)
{
    dht_activo = 0u;
    DHT11_Data_Write(LINEA_LIBRE);
}
