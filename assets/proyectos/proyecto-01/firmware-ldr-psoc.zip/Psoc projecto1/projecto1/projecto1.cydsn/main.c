#include "project.h"
#include <stdio.h>
#include "LiquidCrystal_I2C.h"

int main(void)
{
    CyGlobalIntEnable; /* Habilitar interrupciones globales */

    /* 1. Inicialización de periféricos */
    /* Ajusta los nombres agregando '_1' si en tu TopDesign se llaman ADC_DelSig_1, I2C_1 o UART_1 */
    ADC_DelSig_1_Start();
    I2C_1_Start();
    UART_1_Start(); /* Inicia la comunicación UART */
    
    /* 2. Inicialización de la pantalla LCD I2C */
    LiquidCrystal_I2C_init(0x27, 16, 2, 0);
    begin();
    
    setCursor(0, 0);
    LCD_print("Sistema LDR");
    CyDelay(1000);
    clear();
    
    /* 3. Variables de trabajo */
    uint32 enteros = 0;
    double voltajes = 0.0;
    double luminosidad = 0.0;
    char buffer[64]; /* Buffer de 64 posiciones para evitar cualquier desbordamiento */
    
    for(;;)
    {
        /* Lectura analógica secuencial */
        ADC_DelSig_1_StartConvert();
        ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_WAIT_FOR_RESULT);
        enteros = ADC_DelSig_1_GetResult32();
        ADC_DelSig_1_StopConvert();
        
        /* Conversión de cuentas a voltios */
        voltajes = ADC_DelSig_1_CountsTo_Volts(enteros);
        
        /* Ecuación del sensor: Porcentaje de Luminosidad (%) */
        luminosidad = (voltajes - 0.008) / 0.0393;
        
        /* Restricción de límites entre 0.0% y 100.0% */
        if (luminosidad < 0.0) {
            luminosidad = 0.0;
        } else if (luminosidad > 100.0) {
            luminosidad = 100.0;
        }
        
        /* --- 1. MOSTRAR EN PANTALLA LCD --- */
        
        /* Fila 0: Porcentaje de Luminosidad */
        snprintf(buffer, sizeof(buffer), "Luz: %.1f %%      ", luminosidad);
        setCursor(0, 0);
        LCD_print(buffer);
        
        /* Fila 1: Voltaje medido */
        snprintf(buffer, sizeof(buffer), "Volt: %.2f V     ", voltajes);
        setCursor(0, 1);
        LCD_print(buffer);
        
        /* --- 2. ENVIAR POR UART A LA PC --- */
        snprintf(buffer, sizeof(buffer), "Luz: %.1f %% | Voltaje: %.2f V\r\n", luminosidad, voltajes);
        UART_1_PutString(buffer);
        
        CyDelay(300); /* Actualización cada 300 ms */
    }
}