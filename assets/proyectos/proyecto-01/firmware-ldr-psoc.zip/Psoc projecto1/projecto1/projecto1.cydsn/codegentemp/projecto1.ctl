-- ======================================================================
-- projecto1.ctl generated from projecto1
-- 09/16/2026 at 03:56
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- I2C_1

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
