# Component constraints for C:\Users\Juan David\Documents\Psoc projecto1\projecto1\projecto1.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\Juan David\Documents\Psoc projecto1\projecto1\projecto1.cydsn\projecto1.cyprj
# Date: Wed, 16 Sep 2026 08:56:20 GMT
